package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class Main7Activity extends AppCompatActivity {
private EditText emailid;
private Button resetpsswrdbtn;
private ProgressBar progressBar;
FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        emailid=(EditText)findViewById(R.id.email);
        resetpsswrdbtn=(Button)findViewById(R.id.resetpsswrd);
        progressBar=(ProgressBar) findViewById(R.id.progressBar);
        auth=FirebaseAuth.getInstance();
        resetpsswrdbtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetpassword();

            }
        }));
    }
    private void  resetpassword()
    {
        String email =emailid.getText().toString().trim();
        if (email.isEmpty())
        {
            emailid.setError("Email is Required");
            emailid.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            emailid.setError("Please Provide Valid Email");
            emailid.requestFocus();
            return;
        }
        progressBar.setVisibility(View.VISIBLE);
        auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(Main7Activity.this,"Check your email to reset your Password", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Main7Activity.this ,  "This Mail ID is not Registered with us", Toast.LENGTH_SHORT).show();
                }
                progressBar.setVisibility(View.INVISIBLE);
            }
        });
    }
}
