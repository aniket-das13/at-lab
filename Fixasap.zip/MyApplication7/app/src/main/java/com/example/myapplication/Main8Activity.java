

package com.example.myapplication;

        import androidx.appcompat.app.AppCompatActivity;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.TextView;
        import android.content.Intent;
        import android.widget.Toast;

        import com.google.firebase.auth.FirebaseAuth;
        import com.google.firebase.auth.FirebaseUser;

public class Main8Activity extends AppCompatActivity {
    private FirebaseAuth mFirebaseauth;
    private TextView memail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        memail = findViewById(R.id.regemail);
        mFirebaseauth = FirebaseAuth.getInstance();

    }

}
