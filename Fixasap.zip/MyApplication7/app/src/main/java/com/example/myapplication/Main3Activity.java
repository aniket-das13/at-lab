package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Main3Activity extends AppCompatActivity {
    TextView textView;
    private EditText regname, regemail, reglocation, regphno, regpassword;
    private Button register;
    private String name, email, location, phno, password;
    private FirebaseAuth auth;
    ProgressBar progressBar4;
    private DatabaseReference reference;
    private DatabaseReference dbRef;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        auth = FirebaseAuth.getInstance();
        reference= FirebaseDatabase.getInstance().getReference();

        regname = findViewById(R.id.regname);
        regemail = findViewById(R.id.regemail);
        reglocation = findViewById(R.id.reglocation);
        regphno = findViewById(R.id.regphno);
        regpassword = findViewById(R.id.regpassword);
        register = findViewById(R.id.register);
        progressBar4=findViewById(R.id.progressBar4);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateData();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (auth.getCurrentUser() != null) {
            openMain();
        }
    }

    private void openMain() {
        startActivity(new Intent(this, Main6Activity.class));
        finish();
    }

    private void validateData() {
        name = regname.getText().toString();
        email = regemail.getText().toString();
        location = reglocation.getText().toString();
        phno = regphno.getText().toString();
        password = regpassword.getText().toString();
        if (name.isEmpty()) {
            regname.setError("Required");
            regname.requestFocus();

        } else if (email.isEmpty()) {
            regname.setError("Required");
            regname.requestFocus();

        } else if (location.isEmpty()) {
            regname.setError("Required");
            regname.requestFocus();

        } else if (phno.isEmpty()) {
            regname.setError("Required");
            regname.requestFocus();

        } else if (password.isEmpty()) {
            regname.setError("Required");
            regname.requestFocus();
        } else {
            createUser();
        }
    }

    private void createUser() {
        progressBar4.setVisibility(View.VISIBLE);
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            uploadData();
                        } else {
                            Toast.makeText(Main3Activity.this, "Error:" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Main3Activity.this, "Error:" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void uploadData() {
        dbRef = reference.child("users");
        String key = dbRef.push().getKey();
        HashMap<String,String> user=new HashMap<>();
        user.put("key",key);
        user.put("name",name);
        user.put("email",email);
        user.put("location",location);
        user.put("phone_no",phno);
        dbRef.child(key).setValue(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {

                            Toast.makeText(Main3Activity.this, "User Account Created",Toast.LENGTH_SHORT).show();
                            openMain();
                        } else {
                            Toast.makeText(Main3Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        progressBar4.setVisibility(View.INVISIBLE);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Main3Activity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });

    }
}
